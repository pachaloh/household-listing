


#Function that selects EAs randomly
##################################################################

samplePCV = function (nsize = 4, threshold = 5, data){
  
  library(haven)
  library(doBy)
  library(writexl)
  
  data <- data[rowSums(is.na(data)) != ncol(data),]
  
  sampled.eas <- NA
  ctr = 1  
  
  zone_codes <- unique(data$dist_code)                                   	#Extract unique dist_code values
  
  for (i in zone_codes){                                                	#Loop through the unique values of dist_code
    #ctr = 1                                                             	#To count number of sample iterations
    dist_name_data <- data[which(data$dist_code==i),]
    cat("Dist Name:", i,"\n")
    cat("No of EAs:", nsize[ctr],"\n")
    sampleSel <- sample(1:nrow(dist_name_data),nsize[ctr])                #Sample numbers corresponding to EAs
    sel_data <- dist_name_data[sampleSel,]                                #Attach corresponding info to the EAS
    
    sampled.eas <- rbind(sampled.eas,sel_data)  

    cat("------------------------------\n")
    print(sel_data)
    ctr = ctr + 1
  }
  
  write_xlsx(sampled.eas,"pcv-sampled-eas.xlsx")
  return(sampled.eas)
  
}


library(readxl)
library(haven)

framePCV   <- read_excel("sampling_frame.xlsx", sheet = "EAsWithinHFCA")

#Number of selected EAs. Care needs to be taken on the order
cluster_size = c(5,6,3,8,6,4,7,8,9,5,5,3,4,5,4,4,6,7,3,4,5,3,4,5,2,3,4,3,5)

sample_draw <- samplePCV(cluster_size,1,framePCV)

cbind(table(sample_draw$dist_code))
cbind(table(sample_draw$dist_name))


